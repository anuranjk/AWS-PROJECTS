
const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const path = require('path');

const app = express();
const port = 3000;

// Middleware to parse JSON bodies
app.use(express.json());

// Serve static files from the 'public' directory
app.use(express.static('public'));

// Initialize the database
const db = new sqlite3.Database('./quotes.db', (err) => {
  if (err) {
    console.error(err.message);
  }
  console.log('Connected to the quotes database.');
});

// Create the quotes table if it doesn't exist
db.run('CREATE TABLE IF NOT EXISTS quotes (id INTEGER PRIMARY KEY AUTOINCREMENT, quote TEXT NOT NULL)');

// API endpoint to add a new quote
app.post('/api/quotes', (req, res) => {
  const { quote } = req.body;
  if (!quote || quote.trim() === '') {
    return res.status(400).json({ error: 'Quote cannot be empty' });
  }

  const stmt = db.prepare('INSERT INTO quotes (quote) VALUES (?)');
  stmt.run(quote, function (err) {
    if (err) {
      return res.status(500).json({ error: err.message });
    }
    res.status(201).json({ id: this.lastID });
  });
  stmt.finalize();
});

// API endpoint to get a random quote
app.get('/api/quotes/random', (req, res) => {
  db.get('SELECT * FROM quotes ORDER BY RANDOM() LIMIT 1', (err, row) => {
    if (err) {
      return res.status(500).json({ error: err.message });
    }
    res.json(row);
  });
});

// Start the server
app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});
