
document.addEventListener('DOMContentLoaded', () => {
  const quoteForm = document.getElementById('quote-form');
  const quoteInput = document.getElementById('quote-input');
  const message = document.getElementById('message');
  const randomQuoteBtn = document.getElementById('random-quote-btn');
  const randomQuoteDisplay = document.getElementById('random-quote-display');

  // Submit a new quote
  quoteForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const quote = quoteInput.value.trim();

    if (quote === '') {
      message.textContent = 'Quote cannot be empty';
      return;
    }

    try {
      const response = await fetch('/api/quotes', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ quote }),
      });

      if (response.ok) {
        message.textContent = 'Quote submitted successfully!';
        quoteInput.value = '';
      } else {
        const data = await response.json();
        message.textContent = data.error || 'Failed to submit quote';
      }
    } catch (error) {
      message.textContent = 'An error occurred. Please try again.';
    }
  });

  // Get a random quote
  randomQuoteBtn.addEventListener('click', async () => {
    try {
      const response = await fetch('/api/quotes/random');
      if (response.ok) {
        const data = await response.json();
        if (data) {
          randomQuoteDisplay.textContent = `"${data.quote}"`;
        } else {
          randomQuoteDisplay.textContent = 'No quotes found. Submit one!';
        }
      } else {
        randomQuoteDisplay.textContent = 'Failed to fetch a quote.';
      }
    } catch (error) {
      randomQuoteDisplay.textContent = 'An error occurred. Please try again.';
    }
  });
});
