# Quote App

This is a simple full-stack web application for submitting and viewing quotes.

## Database

This application uses SQLite, a lightweight, file-based database. 

- **No installation required:** You do not need to install any separate database software.
- **Automatic setup:** The database file, `quotes.db`, will be automatically created in the root of the project directory when you first start the server.

## Setup and Deployment on an EC2 Instance

### 1. Connect to your EC2 Instance

Connect to your EC2 instance using SSH.

```bash
ssh -i /path/to/your-key.pem ec2-user@your-ec2-public-ip
```

### 2. Install Node.js and npm

Update the package manager and install Node.js.

```bash
# For Amazon Linux 2
sudo yum update -y
curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.1/install.sh | bash
. ~/.nvm/nvm.sh
nvm install --lts

# For Ubuntu
sudo apt-get update
sudo apt-get install -y nodejs npm
```

### 3. Clone the Application

Clone this repository to your EC2 instance.

```bash
git clone https://github.com/your-username/quote-app.git
cd quote-app
```

### 4. Install Dependencies

Install the necessary npm packages.

```bash
npm install
```

### 5. Start the Application Server

Start the Node.js server.

```bash
node server.js
```

The application will be running on port 3000. You can access it in your browser at `http://your-ec2-public-ip:3000`.

### 6. (Optional) Use a Process Manager (pm2)

For production, it's recommended to use a process manager like `pm2` to keep the application running in the background.

```bash
sudo npm install -g pm2
pm2 start server.js
```

### 7. (Optional) Configure Nginx as a Reverse Proxy

To make the application accessible on the standard HTTP port (80), you can use Nginx as a reverse proxy.

```bash
# Install Nginx
sudo yum install nginx -y # For Amazon Linux 2
sudo apt-get install nginx -y # For Ubuntu

# Configure Nginx
sudo nano /etc/nginx/conf.d/default.conf
```

Paste the following configuration into the file:

```nginx
server {
    listen 80;
    server_name your-ec2-public-ip;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}
```

Start and enable Nginx:

```bash
sudo systemctl start nginx
sudo systemctl enable nginx
```

Now you can access the application at `http://your-ec2-public-ip`.