# Containerizing the Quote App (with SQLite)

This guide provides step-by-step instructions to containerize the quote application using Docker while continuing to use the existing SQLite database. No code changes are required for this approach.

## Prerequisites

- [Docker](https://www.docker.com/get-started) installed on your machine.

## Step 1: Create a `Dockerfile`

Create a file named `Dockerfile` in the root of your project with the following content. This file tells Docker how to build an image for your application.

```dockerfile
# Use an official Node.js runtime as a parent image
FROM node:18

# Set the working directory in the container
WORKDIR /usr/src/app

# Copy package.json and package-lock.json
COPY package*.json ./

# Install app dependencies
RUN npm install

# Copy app source
COPY . .

# Expose the port the app runs on
EXPOSE 3000

# Define the command to run the app
CMD [ "node", "server.js" ]
```

## Step 2: Create a `docker-compose.yml` File

Create a file named `docker-compose.yml` in the root of your project. This file will define how to run your application container and ensure that the `quotes.db` file is persisted.

```yaml
version: '3.8'
services:
  app:
    build: .
    ports:
      - "3000:3000"
    volumes:
      - .:/usr/src/app
```

**Explanation of the `volumes` section:**

- `.:/usr/src/app`: This mounts the current directory on your host machine to the `/usr/src/app` directory inside the container. This means any changes you make to your local files (including the `quotes.db` file) will be reflected inside the container, and any changes the container makes (like adding a new quote to the database) will be saved to your local `quotes.db` file.

## Step 3: Build and Run the Container

Now you can build and run your application using Docker Compose.

1.  **Open a terminal** in the root of your project.
2.  **Run the following command** to build the image and start the container in detached mode:

    ```bash
    docker-compose up -d --build
    ```

3.  **Verify that the container is running**:

    ```bash
    docker-compose ps
    ```

    You should see the `app` container running.

4.  **Access your application** by opening a web browser and navigating to `http://localhost:3000`.

## Important Considerations and Limitations

This approach is simple and works well for local development with a single container. However, there are important limitations to consider, especially for production or multi-container setups:

-   **Scalability:** SQLite is a file-based database and is not designed for concurrent access from multiple processes. You cannot run multiple instances (replicas) of your application container, as they would all try to read and write to the same database file, leading to corruption and errors.
-   **Data Portability:** Your data is tied to the `quotes.db` file on the host machine. If you want to move your application to a different server, you must also move this file.

## Recommendation for Production and Scalability

For a production environment or if you plan to scale your application by running multiple containers, it is **highly recommended** to migrate to a client-server database like **PostgreSQL** or **MySQL**.

-   **Using a Database Container:** You can run a PostgreSQL or MySQL database in a separate Docker container and have your application container connect to it. This is a common pattern for development and testing.
-   **Using a Managed Database Service (e.g., AWS RDS):** For the best performance, reliability, and scalability in production, you should use a managed database service like **Amazon RDS**. Your application container would then connect to the RDS instance over the network.

Switching to a client-server database would require code changes (as outlined in the previous version of this guide) but would provide a much more robust and scalable solution.